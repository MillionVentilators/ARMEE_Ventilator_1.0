/*---------------------------------------------------------------------------*\
  =========                 |
  \\      /  F ield         | OpenFOAM: The Open Source CFD Toolbox
   \\    /   O peration     | Website:  https://openfoam.org
    \\  /    A nd           | Copyright (C) 2020 OpenFOAM Foundation
     \\/     M anipulation  |
-------------------------------------------------------------------------------
License
    This file is part of OpenFOAM.

    OpenFOAM is free software: you can redistribute it and/or modify it
    under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    OpenFOAM is distributed in the hope that it will be useful, but WITHOUT
    ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
    FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License
    for more details.

    You should have received a copy of the GNU General Public License
    along with OpenFOAM.  If not, see <http://www.gnu.org/licenses/>.

\*---------------------------------------------------------------------------*/

#include "lungPressureFvPatchScalarField.H"
#include "addToRunTimeSelectionTable.H"
#include "fvPatchFieldMapper.H"
#include "volFields.H"
#include "surfaceFields.H"

#if WM_PROJECT_VERSION == 7
const scalar NaN = vGreat;
#endif

// * * * * * * * * * * * * * * * * Constructors  * * * * * * * * * * * * * * //

Foam::lungPressureFvPatchScalarField::lungPressureFvPatchScalarField
(
    const fvPatch& p,
    const DimensionedField<scalar, volMesh>& iF
)
:
    inletOutletPressureFvPatchScalarField(p, iF),
    C_(NaN),
    R_(NaN),
    I_(NaN),
    V_(NaN),
    V0_(NaN),
    dVdt_(NaN),
    dVdt0_(NaN),
    timeIndex_(-1)
{
}


Foam::lungPressureFvPatchScalarField::lungPressureFvPatchScalarField
(
    const fvPatch& p,
    const DimensionedField<scalar, volMesh>& iF,
    const dictionary& dict
)
:
    inletOutletPressureFvPatchScalarField
    (
        p,
        iF,
        dict.lookupOrDefault<word>("phi", "phi"),
        scalarField("value", dict, p.size())
    ),
    C_(readScalar(dict.lookup("C"))),
    R_(readScalar(dict.lookup("R"))),
    I_(readScalar(dict.lookup("I"))),
    V_(readScalar(dict.lookup("V"))),
    V0_(NaN),
    dVdt_(dict.lookupOrDefault<scalar>("dVdt", 0)),
    dVdt0_(NaN),
    timeIndex_(-1)
{
}


Foam::lungPressureFvPatchScalarField::lungPressureFvPatchScalarField
(
    const lungPressureFvPatchScalarField& ptf,
    const fvPatch& p,
    const DimensionedField<scalar, volMesh>& iF,
    const fvPatchFieldMapper& mapper
)
:
    inletOutletPressureFvPatchScalarField(ptf, p, iF, mapper),
    C_(ptf.C_),
    R_(ptf.R_),
    I_(ptf.I_),
    V_(ptf.V_),
    V0_(ptf.V0_),
    dVdt_(ptf.dVdt_),
    dVdt0_(ptf.dVdt0_),
    timeIndex_(-1)
{}


Foam::lungPressureFvPatchScalarField::lungPressureFvPatchScalarField
(
    const lungPressureFvPatchScalarField& ptf
)
:
    inletOutletPressureFvPatchScalarField(ptf),
    C_(ptf.C_),
    R_(ptf.R_),
    I_(ptf.I_),
    V_(ptf.V_),
    V0_(ptf.V0_),
    dVdt_(ptf.dVdt_),
    dVdt0_(ptf.dVdt0_),
    timeIndex_(-1)
{}


Foam::lungPressureFvPatchScalarField::lungPressureFvPatchScalarField
(
    const lungPressureFvPatchScalarField& ptf,
    const DimensionedField<scalar, volMesh>& iF
)
:
    inletOutletPressureFvPatchScalarField(ptf, iF),
    C_(ptf.C_),
    R_(ptf.R_),
    I_(ptf.I_),
    V_(ptf.V_),
    V0_(ptf.V0_),
    dVdt_(ptf.dVdt_),
    dVdt0_(ptf.dVdt0_),
    timeIndex_(-1)
{}


// * * * * * * * * * * * * * * * Member Functions  * * * * * * * * * * * * * //

void Foam::lungPressureFvPatchScalarField::updateCoeffs()
{
    if (updated())
    {
        return;
    }

    const fvsPatchField<scalar>& phi =
        patch().lookupPatchField<surfaceScalarField, scalar>(phiName_);

    const scalar dt = db().time().deltaTValue();

    if (timeIndex_ != db().time().timeIndex())
    {
        V0_ = V_;
        dVdt0_ = dVdt_;
    }

    dVdt_ = gSum(phi);

    V_ = V0_ + dVdt_*dt;

    const scalar d2Vdt2 = (dVdt_ - dVdt0_)/dt;

    Info<< type() << " condition on " << patch().name() << " boundary: "
        << "V,dVdt,d2Vdt2 = " << V_ << ',' << dVdt_ << ',' << d2Vdt2 << endl;

    p0_ = V_/C_ + R_*dVdt_ + I_*d2Vdt2;

    inletOutletPressureFvPatchScalarField::updateCoeffs();
}


void Foam::lungPressureFvPatchScalarField::write
(
    Ostream& os
) const
{
    fixedValueFvPatchScalarField::write(os);
    writeEntryIfDifferent<word>(os, "phi", "phi", phiName_);
    writeEntry(os, "C", C_);
    writeEntry(os, "R", R_);
    writeEntry(os, "I", I_);
    writeEntry(os, "V", V_);
    writeEntry(os, "dVdt", dVdt_);
}


// * * * * * * * * * * * * * * Build Macro Function  * * * * * * * * * * * * //

namespace Foam
{
    makePatchTypeField
    (
        fvPatchScalarField,
        lungPressureFvPatchScalarField
    );
}

// ************************************************************************* //
